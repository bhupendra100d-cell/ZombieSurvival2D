package com.zombiesurvival2d;
import android.app.*; import android.os.*; import android.webkit.*; import android.view.*;
public class MainActivity extends Activity { public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(1024,1024);WebView w=new WebView(this);w.getSettings().setJavaScriptEnabled(true);w.getSettings().setDomStorageEnabled(true);w.loadUrl("file:///android_asset/game.html");setContentView(w);} }
